<?php

return [
    'site_title' => 'Event Management',

];
